package Lab1;
import java.util.Scanner;

public class CalculateDifference{
	public static int difference(int n)
	{
		int sumSquare=(n*(n+1*(2*n+1)))/6;
		int sumN=(n*(n+1))/2;
		int squareSumN=sumN*sumN;
		return Math.abs(sumSquare - squareSumN);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=6;
		System.out.println("Number: "+n);
		System.out.println("Difference: "+difference(n));

	}

}
