package Lab5;
public class InvalidNameException extends Exception{
public InvalidNameException(String message) {
super(message);
}
}