package Lab1;
import java.util.Scanner;
public class Calculate {
	public void sum()
	{

		int n,sum=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number");
		n=sc.nextInt();
        for(int i=0;i<=n;i++)
        {
        	if(i%3==0 && i%5==0)
        	{
        		sum=sum+i;
        	}
        }
        System.out.println(sum);
	}

public static void main(String[] args)
{
	Calculate calculate=new Calculate();
	calculate.sum();
}
}
